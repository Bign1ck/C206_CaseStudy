import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class C206_CaseStudyTest {

    private List<Users> userList;
    private List<Activity> activityList;
    private List<Registration> registrationList;
    private List<ApprovalStatus> approvalStatusList;
	private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final ByteArrayInputStream mockInput = new ByteArrayInputStream("1\n".getBytes());

    @Before
    public void setUp() {
        // Initialize the lists before each test
        userList = new ArrayList<>();
        activityList = new ArrayList<>();
        registrationList = new ArrayList<>();
        approvalStatusList = new ArrayList<>();

        Users user1 = new Users("John Doe", "123456", null, null);
        userList.add(user1);

        Users user2 = new Users("Jane Smith", "789012", null, null);
        userList.add(user2);
    }

    @After
    public void tearDown() {
        // Clean up resources after each test
        userList = null;
        activityList = null;
        registrationList = null;
        approvalStatusList = null;
    }

    @Test
    public void testAddUser() {
        // Create an instance of UserManagement
        UserManagement userManagement = new UserManagement();
        // Call the addUser method
        userManagement.addUser("John Doe", "12345", "S_john_doe", "S");

        // Assertions for checking the added user's details
        assertEquals(3, userList.size()); // Assuming the setup added 2 users
        assertEquals("John Doe", userList.get(2).getName());
        assertEquals("12345", userList.get(2).getStudentId());
        assertEquals("S_john_doe", userList.get(2).getUsername());
        assertEquals("S", userList.get(2).getRole());
    }

    @Test
    public void testViewUsersEmpty() {
        // Create an instance of UserManagement
        UserManagement userManagement = new UserManagement();

        // Create an instance of ByteArrayOutputStream to capture the output
        ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));

        // Call the viewUsers method
        userManagement.viewUsers();

        // Verify the output
        String expectedOutput = "--------------------------------------------------------------------------------\n" +
                                "USERS LIST\n" +
                                "--------------------------------------------------------------------------------\n" +
                                "No users found.\n" +
                                "--------------------------------------------------------------------------------";
        assertEquals(expectedOutput, outputStreamCaptor.toString().trim());
    }

    @Test
    public void testViewUsersNonEmpty() {
        // Create an instance of UserManagement
        UserManagement userManagement = new UserManagement();

        // Create an instance of ByteArrayOutputStream to capture the output
        ByteArrayOutputStream outputStreamCaptor = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStreamCaptor));

        // Call the viewUsers method
        userManagement.viewUsers();

        // Verify the output (This should show user list details if userList is populated)
        String expectedOutput = "--------------------------------------------------------------------------------\n" +
                                "USERS LIST\n" +
                                "--------------------------------------------------------------------------------\n" +
                                "No users found.\n" +
                                "--------------------------------------------------------------------------------";
        assertEquals(expectedOutput, outputStreamCaptor.toString().trim());
    }

    @Test
    public void testDeleteUser() {
        // Test deleteUser() method
        String userID = "1234567";
        boolean executeDelete = false;
        boolean deleted = false;

        // Implement the test for deleteUser() method here
        for (Users user : userList) {
            executeDelete = user.getStudentId().equalsIgnoreCase(userID);
            if (executeDelete) {
                userList.remove(user);
                System.out.println("User deleted successfully!");
                break;
            }
        }
        for (Users user : userList) {
            deleted = user.getStudentId().equalsIgnoreCase(userID);
        }
        assertFalse("user has been deleted", deleted);
    }
	
		@Test
		public void testAddActivity() {
			// Test addActivity() method
			// Add your test input
			String activityName = "Test Activity";
			int capacity = 10;
			String prerequisites = "Test Prerequisites";
	
			// Call the addActivity() method with test input
			Helper.setInput(activityName + "\n" + capacity + "\n" + prerequisites);
			addActivity();
	
			// Assert that the activityList has one item (the activity added)
			Assert.assertEquals(1, activityList.size());
			// Assert that the activity details are as expected
			Assert.assertEquals(activityName, activityList.get(0).getActivityName());
			Assert.assertEquals(capacity, activityList.get(0).getCapacity());
			Assert.assertEquals(prerequisites, activityList.get(0).getPrerequisites());
		}
	
		@Test
		public void testViewActivitiesEmpty() {
			// Test viewActivities() method when activityList is empty
			// Call the viewActivities() method
			viewActivities();
	
			// Assert that the output contains the "No activities found." message
			Assert.assertTrue(Helper.getOutput().contains("No activities found."));
		}
	
		@Test
		public void testViewActivitiesNonEmpty() {
			activityList.add(new Activity("Activity 1", 10, "Prereq 1"));
			activityList.add(new Activity("Activity 2", 15, "Prereq 2"));
	
			viewActivities();
	
			Assert.assertTrue(Helper.getOutput().contains("ID       Activity Name   Capacity  Prerequisites"));
			Assert.assertTrue(Helper.getOutput().contains("1        Activity 1      10        Prereq 1"));
			Assert.assertTrue(Helper.getOutput().contains("2        Activity 2      15        Prereq 2"));
		}
	

		public void testDeleteActivity() {
			YourClass yourClass = new YourClass(); // Replace YourClass with the actual class name
	
			// Adding sample activities to the activityList
			Activity activity1 = new Activity("Swimming", 20, "Swimming goggles");
			Activity activity2 = new Activity("Yoga", 15, "Yoga mat");
			activityList.add(activity1);
			activityList.add(activity2);
	
			// Adding sample time slots
			TimeSlot timeSlot1 = new TimeSlot(new Date(), new Date(), activityList.get(0));
			TimeSlot timeSlot2 = new TimeSlot(new Date(), new Date(), activityList.get(1));
			timeSlotList.add(timeSlot1);
			timeSlotList.add(timeSlot2);
	
			// Adding sample registrations
			Registration registration1 = new Registration(userList.get(0), activityList.get(0), "Pending");
			Registration registration2 = new Registration(userList.get(1), activityList.get(1), "Approved");
			registrationList.add(registration1);
			registrationList.add(registration2);
	
			// Adding sample approval statuses
			ApprovalStatus approvalStatus1 = new ApprovalStatus("Pending");
			ApprovalStatus approvalStatus2 = new ApprovalStatus("Approved");
			ApprovalStatus approvalStatus3 = new ApprovalStatus("Rejected");
			approvalStatusList.add(approvalStatus1);
			approvalStatusList.add(approvalStatus2);
			approvalStatusList.add(approvalStatus3);
	
			// Adding sample attendances
			Attendance attendance1 = new Attendance(userList.get(0), timeSlotList.get(0), new Date());
			Attendance attendance2 = new Attendance(userList.get(1), timeSlotList.get(1), new Date());
			attendanceList.add(attendance1);
			attendanceList.add(attendance2);
	
			int activityIdToDelete = 1;
			yourClass.deleteActivity(activityIdToDelete);

			assertTrue(activityList.stream().noneMatch(activity -> activity.getActivityId() == activityIdToDelete));
			assertTrue(timeSlotList.stream().noneMatch(timeSlot -> timeSlot.getActivity().getActivityId() == activityIdToDelete));
			assertTrue(registrationList.stream().noneMatch(registration -> registration.getActivity().getActivityId() == activityIdToDelete));
	
		}	

		//------------------------------------------------------------------------------------------------------------------------------------
		//-----------------------------------------------------------------------------------------------------------------------------------
		//-----------------------------------------------------------------------------------------------------------------------------------

        @Test
        public void testAddRegistration() {
			// Create a test user and activity
			Users testUser = userList.get(0); // Use the first user for testing
			Activity testActivity = new Activity("Chess Club", 20);
	
			// Simulate user input (assuming you have a simulated input mechanism)
			Helper.setInputForTesting("123456\n1\n");
	
			// Call the method that you want to test
			testAddRegistration();
	
			// Verify that the registration has been added successfully
			assertEquals(1, registrationList.size());
			Registration addedRegistration = registrationList.get(0);
			assertEquals(testUser, addedRegistration.getUser());
			assertEquals(testActivity, addedRegistration.getActivity());
			assertEquals("Pending", addedRegistration.getStatus());
	
			// Verify that the system prints the success message
			assertEquals("Registration added successfully.", Helper.getOutputForTesting());
		}
	

	@Test
	public void testViewRegistrationsEmpty() {
		// Test viewRegistrations() method when registrationList is empty
        System.setOut(new PrintStream(outContent));

        // Call the viewRegistrations() method
        testViewActivitiesEmpty();

        // Reset System.out to its original value
        System.setOut(originalOut);

        // Assert that the printed output matches the expected message for empty list
        String expectedOutput = "No registrations found.\n";
        assertEquals(expectedOutput, outContent.toString());
    }

	@Test
	public void testViewRegistrationsNonEmpty() {
		// Prepare sample data for registrationList
        Users user = new Users("John Doe", "123456", null, null);
        Activity activity = new Activity("Chess Club", 20);
        Registration registration = new Registration(user, activity, "Pending");
        registrationList.add(registration);

        // Redirect System.out to outContent for capturing printed output
        System.setOut(new PrintStream(outContent));

        // Call the viewRegistrations() method
        testViewActivitiesNonEmpty();

        // Reset System.out to its original value
        System.setOut(originalOut);

        // Assert that the printed output matches the expected format
        String expectedOutput = "--------------------------------------------------------------------------------\n" +
                "Registration ID  User                           Activity            Status         \n" +
                "--------------------------------------------------------------------------------\n" +
                String.format("%-15s %-30s %-20s %-15s%n", registration.getRegistrationId(), user.getName(), activity.getActivityName(), registration.getStatus()) +
                "--------------------------------------------------------------------------------\n";
        assertEquals(expectedOutput, outContent.toString());
    }

	@Test
	public void testDeleteRegistration() {
        // Prepare sample data for registrationList
        Users user = new Users("John Doe", "123456", null, null);
        Activity activity = new Activity("Chess Club", 20);
        Registration registration = new Registration(user, activity, "Pending");
        registrationList.add(registration);

        // Redirect System.out to outContent for capturing printed output
        System.setOut(new PrintStream(outContent));

        // Redirect System.in to mockInput for simulating user input
        System.setIn(mockInput);

        // Call the deleteRegistration() method
        testDeleteRegistration();

        // Reset System.out and System.in to their original values
        System.setOut(originalOut);
        System.setIn(System.in);

        // Assert that the printed output matches the expected message
        String expectedOutput = "------------------------\n" +
                "Delete Registration\n" +
                "------------------------\n" +
                "All Registrations:\n" +
                "Reg. ID User                           Activity            Status             \n" +
                "--------------------------------------------------------------------------------\n" +
                String.format("%-5s %-15s %-30s %-20s ", registration.getRegistrationId(), user.getName(), activity.getActivityName(), registration.getStatus()) +
                "\n--------------------------------------------------------------------------------\n" +
                "Enter the ID of the registration to delete: " +
                "Registration with ID 1 has been deleted.\n";

        assertEquals(expectedOutput, outContent.toString());
        assertEquals(0, registrationList.size()); // Check that the registration was removed from the list
    }

	//-----------------------------------------------------------------------------------------------------------------------------------
	//-----------------------------------------------------------------------------------------------------------------------------------
	//-----------------------------------------------------------------------------------------------------------------------------------

	@Test
	public void testAddApprovalStatus() {
		System.setOut(new PrintStream(outContent));

        // Redirect user input to simulate providing the approval status name
        Helper.setInputForTesting("Pending\n");

        // Call the addApprovalStatus() method
        testAddApprovalStatus();

        // Reset System.out and user input to their original values
        System.setOut(originalOut);
        Helper.resetTestingInput();

        // Assert that the printed output matches the expected message
        String expectedOutput = "------------------------\n" +
                "Add New Approval Status\n" +
                "------------------------\n" +
                "Approval status added successfully!\n";

        assertEquals(expectedOutput, outContent.toString());

        // Assert that the new approval status is correctly added to the list
        assertEquals(1, approvalStatusList.size());
        assertEquals("Pending", approvalStatusList.get(0).getStatus());
    }

	@Test
	public void testViewApprovalStatusesEmpty() {
		System.setOut(new PrintStream(outContent));

        // Call the viewApprovalStatuses() method when approvalStatusList is empty
        testViewApprovalStatusesEmpty();

        // Reset System.out to its original value
        System.setOut(originalOut);

        // Assert that the printed output matches the expected message
        String expectedOutput = "------------------------\n" +
                "View All Approval Statuses\n" +
                "------------------------\n" +
                "No approval statuses found.\n";
        assertEquals(expectedOutput, outContent.toString());
    }

	@Test
	public void testViewApprovalStatusesNonEmpty() {
		ApprovalStatus status1 = new ApprovalStatus("Pending");
        ApprovalStatus status2 = new ApprovalStatus("Approved");
        approvalStatusList.add(status1);
        approvalStatusList.add(status2);

        // Redirect System.out to outContent for capturing printed output
        System.setOut(new PrintStream(outContent));

        // Call the viewApprovalStatuses() method when approvalStatusList is not empty
        testViewApprovalStatusesNonEmpty();

        // Reset System.out to its original value
        System.setOut(originalOut);

        // Assert that the printed output matches the expected message
        String expectedOutput = "------------------------\n" +
                "View All Approval Statuses\n" +
                "------------------------\n" +
                "Approval Statuses:\n" +
                "ID    Status Name         \n" +
                "---------------------------\n" +
                "1     Pending             \n" +
                "2     Approved            \n";

        assertEquals(expectedOutput, outContent.toString());
    }

	@Test
	public void testDeleteApprovalStatus() {
		// Prepare sample approval statuses
        ApprovalStatus status1 = new ApprovalStatus("Pending");
        ApprovalStatus status2 = new ApprovalStatus("Approved");
        approvalStatusList.add(status1);
        approvalStatusList.add(status2);

        // Redirect System.out to outContent for capturing printed output
        System.setOut(new PrintStream(outContent));

        // Simulate user input for deleting an approval status
        Helper.setInputForTesting("1\n");

        // Call the deleteApprovalStatus() method
        testDeleteApprovalStatus();

        // Reset System.out and user input to their original values
        System.setOut(originalOut);
        Helper.resetTestingInput();

        // Assert that the printed output matches the expected message
        String expectedOutput = "------------------------\n" +
                "Delete Approval Status\n" +
                "------------------------\n" +
                "All Approval Statuses:\n" +
                "ID    Status     \n" +
                "---------------------------\n" +
                "1     Pending    \n" +
                "2     Approved   \n" +
                "Approval status with ID 1 has been deleted: Status: Pending\n";

        assertEquals(expectedOutput, outContent.toString());

        // Assert that the correct approval status was removed from the list
        assertEquals(1, approvalStatusList.size());
        assertEquals("Approved", approvalStatusList.get(0).getStatus());
    }
}